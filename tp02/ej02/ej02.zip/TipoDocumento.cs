﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ej02
{
    public enum TipoDocumento
    {
        DNI,
        CUIT,
        CUIL,
        LE,
        LC
    }
}