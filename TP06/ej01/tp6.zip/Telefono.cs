﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej01
{
    class Telefono
    {
        public int TelefonoId { get; set; }
        public String Numero { get; set; }
        public String Tipo { get; set; }
    }
}
